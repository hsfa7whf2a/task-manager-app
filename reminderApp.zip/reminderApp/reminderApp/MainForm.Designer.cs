﻿namespace reminderApp
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.aboutButton = new System.Windows.Forms.Button();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.saveTasksToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveTasksToFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadTasksToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadTasksFromFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripDropDownButtonSearch = new System.Windows.Forms.ToolStripDropDownButton();
            this.searchByDateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchByTimeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchByWordsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButtonReset = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonAdd = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonTheme = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonAbout = new System.Windows.Forms.ToolStripButton();
            this.dataGridViewTasks = new System.Windows.Forms.DataGridView();
            this.contextMenuGrid = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.editSelectedTaskToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteSelectedTaskToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTasks)).BeginInit();
            this.contextMenuGrid.SuspendLayout();
            this.SuspendLayout();
            // 
            // aboutButton
            // 
            this.aboutButton.Location = new System.Drawing.Point(0, 0);
            this.aboutButton.Name = "aboutButton";
            this.aboutButton.Size = new System.Drawing.Size(75, 23);
            this.aboutButton.TabIndex = 11;
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton1,
            this.toolStripDropDownButtonSearch,
            this.toolStripButtonReset,
            this.toolStripButtonAdd,
            this.toolStripButtonTheme,
            this.toolStripButtonAbout});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.toolStrip1.Size = new System.Drawing.Size(709, 25);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveTasksToolStripMenuItem,
            this.saveTasksToFileToolStripMenuItem,
            this.loadTasksToolStripMenuItem,
            this.loadTasksFromFileToolStripMenuItem});
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(49, 22);
            this.toolStripDropDownButton1.Text = "Файл";
            // 
            // saveTasksToolStripMenuItem
            // 
            this.saveTasksToolStripMenuItem.Name = "saveTasksToolStripMenuItem";
            this.saveTasksToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.saveTasksToolStripMenuItem.Text = "Сохранить";
            this.saveTasksToolStripMenuItem.Click += new System.EventHandler(this.saveTasksToolStripMenuItem_Click);
            // 
            // saveTasksToFileToolStripMenuItem
            // 
            this.saveTasksToFileToolStripMenuItem.Name = "saveTasksToFileToolStripMenuItem";
            this.saveTasksToFileToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.saveTasksToFileToolStripMenuItem.Text = "Сохранить как...";
            this.saveTasksToFileToolStripMenuItem.Click += new System.EventHandler(this.saveTasksToFileToolStripMenuItem_Click);
            // 
            // loadTasksToolStripMenuItem
            // 
            this.loadTasksToolStripMenuItem.Name = "loadTasksToolStripMenuItem";
            this.loadTasksToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.loadTasksToolStripMenuItem.Text = "Загрузить заметки";
            this.loadTasksToolStripMenuItem.Click += new System.EventHandler(this.loadTasksToolStripMenuItem_Click);
            // 
            // loadTasksFromFileToolStripMenuItem
            // 
            this.loadTasksFromFileToolStripMenuItem.Name = "loadTasksFromFileToolStripMenuItem";
            this.loadTasksFromFileToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.loadTasksFromFileToolStripMenuItem.Text = "Загрузить из файла";
            this.loadTasksFromFileToolStripMenuItem.Click += new System.EventHandler(this.loadTasksFromFileToolStripMenuItem_Click);
            // 
            // toolStripDropDownButtonSearch
            // 
            this.toolStripDropDownButtonSearch.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButtonSearch.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.searchByDateToolStripMenuItem,
            this.searchByTimeToolStripMenuItem,
            this.searchByWordsToolStripMenuItem});
            this.toolStripDropDownButtonSearch.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButtonSearch.Name = "toolStripDropDownButtonSearch";
            this.toolStripDropDownButtonSearch.Size = new System.Drawing.Size(55, 22);
            this.toolStripDropDownButtonSearch.Text = "Поиск";
            // 
            // searchByDateToolStripMenuItem
            // 
            this.searchByDateToolStripMenuItem.Name = "searchByDateToolStripMenuItem";
            this.searchByDateToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.searchByDateToolStripMenuItem.Text = "По дате";
            this.searchByDateToolStripMenuItem.Click += new System.EventHandler(this.searchByDateToolStripMenuItem_Click);
            // 
            // searchByTimeToolStripMenuItem
            // 
            this.searchByTimeToolStripMenuItem.Name = "searchByTimeToolStripMenuItem";
            this.searchByTimeToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.searchByTimeToolStripMenuItem.Text = "По времени";
            this.searchByTimeToolStripMenuItem.Click += new System.EventHandler(this.searchByTimeToolStripMenuItem_Click);
            // 
            // searchByWordsToolStripMenuItem
            // 
            this.searchByWordsToolStripMenuItem.Name = "searchByWordsToolStripMenuItem";
            this.searchByWordsToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.searchByWordsToolStripMenuItem.Text = "По тексту";
            this.searchByWordsToolStripMenuItem.Click += new System.EventHandler(this.searchByWordsToolStripMenuItem_Click);
            // 
            // toolStripButtonReset
            // 
            this.toolStripButtonReset.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonReset.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonReset.Name = "toolStripButtonReset";
            this.toolStripButtonReset.Size = new System.Drawing.Size(99, 22);
            this.toolStripButtonReset.Text = "Очистить поиск";
            this.toolStripButtonReset.Click += new System.EventHandler(this.toolStripButtonReset_Click);
            // 
            // toolStripButtonAdd
            // 
            this.toolStripButtonAdd.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonAdd.Name = "toolStripButtonAdd";
            this.toolStripButtonAdd.Size = new System.Drawing.Size(109, 22);
            this.toolStripButtonAdd.Text = "Добавить заметку";
            this.toolStripButtonAdd.Click += new System.EventHandler(this.toolStripButtonAdd_Click);
            // 
            // toolStripButtonTheme
            // 
            this.toolStripButtonTheme.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonTheme.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonTheme.Name = "toolStripButtonTheme";
            this.toolStripButtonTheme.Size = new System.Drawing.Size(38, 22);
            this.toolStripButtonTheme.Text = "Тема";
            this.toolStripButtonTheme.Click += new System.EventHandler(this.toolStripButtonTheme_Click);
            // 
            // toolStripButtonAbout
            // 
            this.toolStripButtonAbout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonAbout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonAbout.Name = "toolStripButtonAbout";
            this.toolStripButtonAbout.Size = new System.Drawing.Size(96, 22);
            this.toolStripButtonAbout.Text = "О Приложении";
            this.toolStripButtonAbout.Click += new System.EventHandler(this.toolStripButtonAbout_Click);
            // 
            // dataGridViewTasks
            // 
            this.dataGridViewTasks.AllowUserToAddRows = false;
            this.dataGridViewTasks.AllowUserToDeleteRows = false;
            this.dataGridViewTasks.AllowUserToResizeColumns = false;
            this.dataGridViewTasks.AllowUserToResizeRows = false;
            this.dataGridViewTasks.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewTasks.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridViewTasks.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.dataGridViewTasks.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTasks.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridViewTasks.GridColor = System.Drawing.Color.WhiteSmoke;
            this.dataGridViewTasks.Location = new System.Drawing.Point(12, 28);
            this.dataGridViewTasks.Name = "dataGridViewTasks";
            this.dataGridViewTasks.Size = new System.Drawing.Size(682, 306);
            this.dataGridViewTasks.TabIndex = 9;
            // 
            // contextMenuGrid
            // 
            this.contextMenuGrid.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.contextMenuGrid.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editSelectedTaskToolStripMenuItem,
            this.deleteSelectedTaskToolStripMenuItem});
            this.contextMenuGrid.Name = "contextMenuGrid";
            this.contextMenuGrid.Size = new System.Drawing.Size(201, 48);
            this.contextMenuGrid.UseWaitCursor = true;
            // 
            // editSelectedTaskToolStripMenuItem
            // 
            this.editSelectedTaskToolStripMenuItem.Name = "editSelectedTaskToolStripMenuItem";
            this.editSelectedTaskToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.editSelectedTaskToolStripMenuItem.Text = "Редактировать заметку";
            this.editSelectedTaskToolStripMenuItem.Click += new System.EventHandler(this.editSelectedTaskToolStripMenuItem_Click);
            // 
            // deleteSelectedTaskToolStripMenuItem
            // 
            this.deleteSelectedTaskToolStripMenuItem.Name = "deleteSelectedTaskToolStripMenuItem";
            this.deleteSelectedTaskToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.deleteSelectedTaskToolStripMenuItem.Text = "Удалить заметку";
            this.deleteSelectedTaskToolStripMenuItem.Click += new System.EventHandler(this.deleteSelectedTaskToolStripMenuItem_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(709, 346);
            this.ContextMenuStrip = this.contextMenuGrid;
            this.Controls.Add(this.dataGridViewTasks);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.aboutButton);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "MainForm";
            this.Text = "Приложение Управления Заметок";
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTasks)).EndInit();
            this.contextMenuGrid.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button aboutButton;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem saveTasksToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveTasksToFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadTasksToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadTasksFromFileToolStripMenuItem;
        private System.Windows.Forms.DataGridView dataGridViewTasks;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButtonSearch;
        private System.Windows.Forms.ToolStripMenuItem searchByDateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchByTimeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchByWordsToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButtonReset;
        private System.Windows.Forms.ContextMenuStrip contextMenuGrid;
        private System.Windows.Forms.ToolStripMenuItem editSelectedTaskToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteSelectedTaskToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButtonAdd;
        private System.Windows.Forms.ToolStripButton toolStripButtonTheme;
        private System.Windows.Forms.ToolStripButton toolStripButtonAbout;
    }
}