﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace reminderApp
{
    public partial class MainForm : Form
    {
        private List<MyTask> tasks = new List<MyTask>();
        public MainForm() {
            InitializeComponent();
            dataGridViewTasks.Columns.Add("TaskDate", "Дата");
            dataGridViewTasks.Columns.Add("TaskText", "Текст");
            dataGridViewTasks.Columns.Add("TaskTime", "Время");
            StartNotificationCheck(); // запуск проверки на отправку уведомления
        }
        private void resetDataGrid() // очищение datagridview
        {
            dataGridViewTasks.DataSource = null;
            dataGridViewTasks.Rows.Clear();
            dataGridViewTasks.Columns.Clear();
            dataGridViewTasks.Columns.Add("TaskDate", "Дата");
            dataGridViewTasks.Columns.Add("TaskText", "Текст");
            dataGridViewTasks.Columns.Add("TaskTime", "Время");
        }
        public class Config { // конфиг для строки подключения
            public string ConnectionString { get; set; }
        }
        private string LoadConnectionString() {
            string json = File.ReadAllText("SQLConn.json");
            Config config = JsonConvert.DeserializeObject<Config>(json);
            return config.ConnectionString;
        }
        private async void StartNotificationCheck() { // отправка уведомления
            while (true) {
                await Task.Delay(30000); // проверяет заметки каждые 30 секунд
                DateTime currentTime = DateTime.Now;
                foreach (var task in tasks) { if (task.TaskDate.Date == currentTime.Date && task.TaskTime.Hour == currentTime.Hour && task.TaskTime.Minute == currentTime.Minute) { 
                        MessageBox.Show($"Your task: {task.TaskText}!\nDated: {task.TaskDate.ToShortDateString()}\nAt: {task.TaskTime.ToLongTimeString()}", "Task reminder!", MessageBoxButtons.OK, MessageBoxIcon.Information); 
                    } 
                } 
            }
        }
        private bool TaskExistsInDatabase(SqlConnection connection, MyTask task) { // проверка на уникальность заметки в базе данных
            string query = "SELECT COUNT(*) FROM [dbo].[Tasks] WHERE Body = @Body AND Date = @Date AND TaskTime = @Time";
            using (SqlCommand command = new SqlCommand(query, connection)) {
                command.Parameters.Add("@Body", SqlDbType.NVarChar).Value = task.TaskText;
                command.Parameters.Add("@Date", SqlDbType.DateTime).Value = task.TaskDate;
                command.Parameters.Add("@Time", SqlDbType.DateTime).Value = task.TaskTime;
                int count = (int)command.ExecuteScalar();
                return count > 0;
            }
        }
        private void saveTasksToolStripMenuItem_Click(object sender, EventArgs e) { // сохранение заметки в базу данных SQL Server
            string connectionString = LoadConnectionString(); // строка подключения
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                connection.Open();
                foreach (MyTask task in tasks) {
                    if (!TaskExistsInDatabase(connection, task)) {
                        string query = "INSERT INTO [dbo].[Tasks] (Body, Date, TaskTime) VALUES (@Body, @Date, @Time)";
                        using (SqlCommand command = new SqlCommand(query, connection)) {
                            command.Parameters.Add("@Body", SqlDbType.NVarChar).Value = task.TaskText;
                            command.Parameters.Add("@Date", SqlDbType.DateTime).Value = task.TaskDate;
                            command.Parameters.Add("@Time", SqlDbType.DateTime).Value = task.TaskTime;
                            try { command.ExecuteNonQuery(); }
                            catch (SqlException ex) { MessageBox.Show("Ошибка при сохранении в базу данных: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                        }
                    }
                }
                MessageBox.Show("Задачи сохранены в базу данных", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
        }
        private void saveTasksToFileToolStripMenuItem_Click(object sender, EventArgs e) { // сохранение заметок в файл
            using (SaveFileDialog saveFileDialog = new SaveFileDialog()) {
                saveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
                if (saveFileDialog.ShowDialog() == DialogResult.OK) {
                    using (StreamWriter sw = new StreamWriter(saveFileDialog.FileName)) {
                        foreach (var task in tasks) {
                            sw.WriteLine(task.ToString()); // построчно
                        }
                    }
                }
            }
        }
        private void loadTasksToolStripMenuItem_Click(object sender, EventArgs e) { // загрузка из базы данных SQL Server
            string connectionString = LoadConnectionString();
            tasks.Clear();
            resetDataGrid(); // очищение datagridview
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                connection.Open();
                string query = "SELECT Body, Date, TaskTime FROM [dbo].[Tasks]";
                using (SqlCommand command = new SqlCommand(query, connection)) {
                    using (SqlDataReader reader = command.ExecuteReader()) {
                        while (reader.Read()) {
                            MyTask task = new MyTask(
                                reader["Body"].ToString(),
                                Convert.ToDateTime(reader["Date"]),
                                (DateTime)reader["TaskTime"]
                            );
                            tasks.Add(task);
                            dataGridViewTasks.Rows.Add(task.TaskDate.ToShortDateString(), task.TaskText, task.TaskTime.ToLongTimeString());
                        }
                    }
                }
            }
        }
        private void loadTasksFromFileToolStripMenuItem_Click(object sender, EventArgs e) { // загрузка заметок из файла
            using (OpenFileDialog openFileDialog = new OpenFileDialog()) {
                openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
                if (openFileDialog.ShowDialog() == DialogResult.OK) {
                    try {
                        using (StreamReader sr = new StreamReader(openFileDialog.FileName)) {
                            tasks.Clear();
                            resetDataGrid(); // очищение datagridview
                            string line;
                            while ((line = sr.ReadLine()) != null) {
                                var parts = line.Split(new[] { " - " }, StringSplitOptions.None); // разбиение на части: дата - текст - время
                                if (parts.Length == 3) {
                                    string taskText = parts[0];
                                    DateTime taskDate = DateTime.Parse(parts[1]);
                                    DateTime taskTime = DateTime.Parse(parts[2]);
                                    MyTask task = new MyTask(taskText, taskDate, taskTime);
                                    tasks.Add(task);
                                    dataGridViewTasks.Rows.Add(task.TaskDate.ToShortDateString(), task.TaskText, task.TaskTime.ToLongTimeString());
                                }
                            }
                        }
                    }
                    catch (Exception ex) { MessageBox.Show("Ошибка при чтении файла: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                }
            }
        }
        private void searchByDateToolStripMenuItem_Click(object sender, EventArgs e) { // фильтрация по дате
            using (Form datePickerForm = new Form()) { // создание окна для выбора даты
                DateTimePicker dateTimePicker = new DateTimePicker{ Format = DateTimePickerFormat.Short, Location = new Point(10, 10) };
                Button confirmButton = new Button{ Text = "Поиск", Location = new Point(10, 40), DialogResult = DialogResult.OK };
                datePickerForm.Controls.Add(dateTimePicker);
                datePickerForm.Controls.Add(confirmButton);
                datePickerForm.ClientSize = new Size(200, 100);
                datePickerForm.StartPosition = FormStartPosition.CenterParent;
                if (datePickerForm.ShowDialog() == DialogResult.OK) {
                    DateTime selectedDate = dateTimePicker.Value.Date;
                    var filteredTasks = tasks.Where(task => task.TaskDate.Date == selectedDate).ToList();
                    resetDataGrid(); // очищение datagridview
                    foreach (var task in filteredTasks) { dataGridViewTasks.Rows.Add(task.TaskDate.ToShortDateString(), task.TaskText, task.TaskTime.ToLongTimeString()); } // отфильтрованный datagridview
                }
            }
        }
        private void searchByTimeToolStripMenuItem_Click(object sender, EventArgs e) { // фильтрация по времени
            using (Form timePickerForm = new Form()) { // создание окна для выбора времени
                DateTimePicker timePicker = new DateTimePicker { Format = DateTimePickerFormat.Time, Location = new Point(10, 10) };
                Button confirmButton = new Button { Text = "Поиск", Location = new Point(10, 40), DialogResult = DialogResult.OK };
                timePickerForm.Controls.Add(timePicker);
                timePickerForm.Controls.Add(confirmButton);
                timePickerForm.ClientSize = new Size(200, 100);
                timePickerForm.StartPosition = FormStartPosition.CenterParent;
                if (timePickerForm.ShowDialog() == DialogResult.OK) {
                    DateTime selectedTime = timePicker.Value;
                    var filteredTasks = tasks.Where(task => task.TaskTime == selectedTime).ToList();
                    resetDataGrid(); // очищение datagridview
                    foreach (var task in filteredTasks) { dataGridViewTasks.Rows.Add(task.TaskDate.ToShortDateString(), task.TaskText, task.TaskTime.ToLongTimeString()); } // отфильтрованный datagridview
                }
            }
        }
        private void searchByWordsToolStripMenuItem_Click(object sender, EventArgs e) { // фильтрация по тексту
            using (Form searchForm = new Form()) { // создание окна для введения текста
                TextBox searchTextBox = new TextBox { Location = new Point(10, 10), Width = 200 };
                Button confirmButton = new Button { Text = "Поиск", Location = new Point(10, 40), DialogResult = DialogResult.OK };
                searchForm.Controls.Add(searchTextBox);
                searchForm.Controls.Add(confirmButton);
                searchForm.ClientSize = new Size(230, 100);
                searchForm.StartPosition = FormStartPosition.CenterParent;
                if (searchForm.ShowDialog() == DialogResult.OK) {
                    string searchText = searchTextBox.Text.Trim().ToLower();
                    var filteredTasks = tasks.Where(task => task.TaskText.ToLower().Contains(searchText)).ToList();
                    resetDataGrid(); // очищение datagridview
                    foreach (var task in filteredTasks) { dataGridViewTasks.Rows.Add(task.TaskDate.ToShortDateString(), task.TaskText, task.TaskTime.ToLongTimeString()); } // отфильтрованный datagridview
                }
            }
        }
        private void toolStripButtonReset_Click(object sender, EventArgs e) {
            resetDataGrid(); // очищение datagridview
            foreach (var task in tasks) { dataGridViewTasks.Rows.Add(task.TaskDate.ToShortDateString(), task.TaskText, task.TaskTime.ToLongTimeString()); }
        }
        private void editSelectedTaskToolStripMenuItem_Click(object sender, EventArgs e) { // изменение заметки
            if (dataGridViewTasks.SelectedRows.Count > 0) {
                int rowIndex = dataGridViewTasks.SelectedRows[0].Index;
                MyTask selectedTask = tasks[rowIndex];
                string oldText = selectedTask.TaskText;
                DateTime oldDate = selectedTask.TaskDate;
                DateTime oldTime = selectedTask.TaskTime;
                CreateTaskForm createTaskForm = new CreateTaskForm(selectedTask.TaskText, selectedTask.TaskDate, selectedTask.TaskTime); // открытие окна для изменения заметки
                if (createTaskForm.ShowDialog() == DialogResult.OK) {
                    selectedTask.TaskText = createTaskForm.TaskText;
                    selectedTask.TaskDate = createTaskForm.TaskDate;
                    selectedTask.TaskTime = createTaskForm.TaskTime;
                    editTaskInDatabase(createTaskForm.TaskText, createTaskForm.TaskDate, createTaskForm.TaskTime, oldText, oldDate, oldTime); // вызов функции для изменение заметки в базе данных
                    dataGridViewTasks.Rows[rowIndex].Cells["TaskText"].Value = selectedTask.TaskText;
                    dataGridViewTasks.Rows[rowIndex].Cells["TaskDate"].Value = selectedTask.TaskDate.ToShortDateString();
                    dataGridViewTasks.Rows[rowIndex].Cells["TaskTime"].Value = selectedTask.TaskTime.ToLongTimeString();
                }
            } else { MessageBox.Show("Пожалуйста, выберите задачу.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
        private void deleteSelectedTaskToolStripMenuItem_Click(object sender, EventArgs e) { // удаление заметки
            if (dataGridViewTasks.SelectedRows.Count > 0) {
                int rowIndex = dataGridViewTasks.SelectedRows[0].Index;
                MyTask selectedTask = tasks[rowIndex];
                tasks.RemoveAt(rowIndex);
                dataGridViewTasks.Rows.RemoveAt(rowIndex);
                removeTaskFromDatabase(selectedTask); // вызов функции для удаления заметки из базы данных
            } else { MessageBox.Show("Пожалуйста, выберите задачу.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
        private void editTaskInDatabase(string Text, DateTime Date, DateTime Time, string oldText, DateTime oldDate, DateTime oldTime) { // внесение изменений в базу данных (кнопка edit)
            string connectionString = LoadConnectionString();
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                connection.Open();
                string query = "UPDATE [dbo].[Tasks] SET Body = @Body, Date = @Date, TaskTime = @Time WHERE Body = @OldBody AND Date = @OldDate AND TaskTime = @OldTime";
                using (SqlCommand command = new SqlCommand(query, connection)) {
                    command.Parameters.AddWithValue("@Body", Text);
                    command.Parameters.AddWithValue("@Date", Date);
                    command.Parameters.AddWithValue("@Time", Time);
                    command.Parameters.AddWithValue("@OldBody", oldText);
                    command.Parameters.AddWithValue("@OldDate", oldDate);
                    command.Parameters.AddWithValue("@OldTime", oldTime);
                    try { command.ExecuteNonQuery(); }
                    catch (Exception ex) { MessageBox.Show("Ошибка при обновлении базы данных: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                }
            }
        }
        private void removeTaskFromDatabase(MyTask task) { // удаление их базы данных (кнопка delete)
            string connectionString = LoadConnectionString();
            using (SqlConnection connection = new SqlConnection(connectionString)) {
                connection.Open();
                string query = "DELETE FROM [dbo].[Tasks] WHERE Body = @Body AND Date = @Date AND TaskTime = @Time";
                using (SqlCommand command = new SqlCommand(query, connection)) {
                    command.Parameters.AddWithValue("@Body", task.TaskText);
                    command.Parameters.AddWithValue("@Date", task.TaskDate);
                    command.Parameters.AddWithValue("@Time", task.TaskTime);
                    try { command.ExecuteNonQuery(); }
                    catch (Exception ex) { MessageBox.Show("Ошибка при удалении из базы данных: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                }
            }
        }
        private void toolStripButtonAdd_Click(object sender, EventArgs e) { // нажатие на кнопку добавления заметки
            CreateTaskForm createTaskForm = new CreateTaskForm(); // открытие окна для создания заметки
            if (createTaskForm.ShowDialog() == DialogResult.OK) {
                MyTask newTask = new MyTask(createTaskForm.TaskText, createTaskForm.TaskDate, createTaskForm.TaskTime); // сохранение данных из окна
                tasks.Add(newTask);
                int rowIndex = dataGridViewTasks.Rows.Add();
                DataGridViewRow row = dataGridViewTasks.Rows[rowIndex];
                row.Cells["TaskDate"].Value = newTask.TaskDate.ToShortDateString();
                row.Cells["TaskText"].Value = newTask.TaskText;
                row.Cells["TaskTime"].Value = newTask.TaskTime.ToLongTimeString();
            }
        }
        private void toolStripButtonAbout_Click(object sender, EventArgs e)  { // открытие информационной формы
            AboutForm aboutUs = new AboutForm();
            aboutUs.ShowDialog();
        }
        private void toolStripButtonTheme_Click(object sender, EventArgs e) { // изменение цвета приложения
            if (this.BackColor == Color.WhiteSmoke) {
                this.toolStrip1.BackColor = Color.SlateGray;
                this.BackColor = Color.LightSlateGray;
                this.ForeColor = Color.White;
                this.dataGridViewTasks.ForeColor = Color.Black;
            } else {
                this.toolStrip1.BackColor = Color.WhiteSmoke;
                this.BackColor = Color.WhiteSmoke;
                this.ForeColor = Color.Black;
            }
        }
    }
    public class MyTask { // класс заметки
        public string TaskText { get; set; }
        public DateTime TaskDate { get; set; }
        public DateTime TaskTime { get; set; }
        public MyTask(string taskText, DateTime taskDate, DateTime taskTime) {
            TaskText = taskText;
            TaskDate = taskDate;
            TaskTime = taskTime;
        }
        public override string ToString() {
            return $"{TaskText} - {TaskDate.ToShortDateString()} - {TaskTime.ToLongTimeString()}";
        }
    }
}
