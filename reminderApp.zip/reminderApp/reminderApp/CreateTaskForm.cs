﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace reminderApp
{
    public partial class CreateTaskForm : Form
    {
        public string TaskText { get; private set; }
        public DateTime TaskDate { get; private set; }
        public DateTime TaskTime { get; set; }
        public CreateTaskForm() : this("", DateTime.Now, DateTime.Now) { }
        public CreateTaskForm(string taskText, DateTime taskDate, DateTime taskTime)
        {
            InitializeComponent();
            taskRTB.Text = taskText;
            taskDTP.Value = taskDate;
            taskTP.Value = taskDate;
        }
        private void finishButton_Click(object sender, EventArgs e)
        {
            if (taskRTB.Text.Length <= 200) {
                TaskText = taskRTB.Text;
                TaskDate = taskDTP.Value;
                TaskTime = taskTP.Value;
                DialogResult = DialogResult.OK;
            } else {
                MessageBox.Show("Максимальная длина текста - 200 символов.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }
    }
}
