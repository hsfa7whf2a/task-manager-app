﻿namespace reminderApp
{
    partial class CreateTaskForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.finishButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.taskDTP = new System.Windows.Forms.DateTimePicker();
            this.taskRTB = new System.Windows.Forms.RichTextBox();
            this.taskTP = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Создание заметки";
            // 
            // finishButton
            // 
            this.finishButton.Location = new System.Drawing.Point(106, 251);
            this.finishButton.Name = "finishButton";
            this.finishButton.Size = new System.Drawing.Size(75, 23);
            this.finishButton.TabIndex = 1;
            this.finishButton.Text = "Сохранить";
            this.finishButton.UseVisualStyleBackColor = true;
            this.finishButton.Click += new System.EventHandler(this.finishButton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Дата и время";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(4, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Текст";
            // 
            // taskDTP
            // 
            this.taskDTP.Location = new System.Drawing.Point(4, 48);
            this.taskDTP.Name = "taskDTP";
            this.taskDTP.Size = new System.Drawing.Size(133, 20);
            this.taskDTP.TabIndex = 3;
            // 
            // taskRTB
            // 
            this.taskRTB.Location = new System.Drawing.Point(4, 92);
            this.taskRTB.Name = "taskRTB";
            this.taskRTB.Size = new System.Drawing.Size(268, 153);
            this.taskRTB.TabIndex = 5;
            this.taskRTB.Text = "";
            // 
            // taskTP
            // 
            this.taskTP.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.taskTP.Location = new System.Drawing.Point(143, 48);
            this.taskTP.Name = "taskTP";
            this.taskTP.Size = new System.Drawing.Size(129, 20);
            this.taskTP.TabIndex = 6;
            // 
            // CreateTaskForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(284, 286);
            this.Controls.Add(this.taskTP);
            this.Controls.Add(this.taskRTB);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.taskDTP);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.finishButton);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "CreateTaskForm";
            this.Text = "Окно Создания Заметок";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button finishButton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker taskDTP;
        private System.Windows.Forms.RichTextBox taskRTB;
        private System.Windows.Forms.DateTimePicker taskTP;
    }
}