﻿ALTER TABLE [dbo].[Tasks]
ADD TaskTime TIME;